"use client";

import React, { useEffect, useRef, useState } from "react";
import maplibregl from "maplibre-gl";
import "maplibre-gl/dist/maplibre-gl.css";

interface MapProps {
  center?: [number, number];
  zoom?: number;
}

export default function Map({
  center = [88.3639, 22.5726],
  zoom = 12,
}: MapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapRef = useRef<maplibregl.Map | null>(null);
  const [hoverInfo, setHoverInfo] = useState<any>(null);

  useEffect(() => {
    if (!mapContainerRef.current) return;

    // Use Carto Dark Matter (which is based on OSM) for the dark, glowing aesthetic
    const map = new maplibregl.Map({
      container: mapContainerRef.current,
      style: {
        version: 8,
        sources: {
          "osm-dark": {
            type: "raster",
            tiles: [
              "https://a.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png",
              "https://b.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png",
              "https://c.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}@2x.png",
            ],
            tileSize: 256,
            attribution:
              '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
          },
        },
        layers: [
          {
            id: "osm-dark-layer",
            type: "raster",
            source: "osm-dark",
            minzoom: 0,
            maxzoom: 20,
          },
        ],
      },
      center: center,
      zoom: zoom,
      pitch: 45, // Add tilt for the cool factor
      bearing: -17.6,
    });

    mapRef.current = map;

    map.on("load", async () => {
      try {
        const response = await fetch("/api/stress-map");
        const geojson = await response.json();

        map.addSource("stress-grid", {
          type: "geojson",
          data: geojson,
        });

        // Heatmap layer glow
        map.addLayer({
          id: "stress-heat",
          type: "heatmap",
          source: "stress-grid",
          maxzoom: 15,
          paint: {
            // Increase the heatmap weight based on the stress_index score
            "heatmap-weight": [
              "interpolate",
              ["linear"],
              ["get", "stress_index"],
              0,
              0,
              100,
              1,
            ],
            // Heatmap intensity as map zooms out
            "heatmap-intensity": [
              "interpolate",
              ["linear"],
              ["zoom"],
              0,
              1,
              15,
              3,
            ],
            // Color scale from Green to Red
            "heatmap-color": [
              "interpolate",
              ["linear"],
              ["heatmap-density"],
              0,
              "rgba(0, 255, 0, 0)", // Transparent
              0.2,
              "rgb(34, 197, 94)", // Green - Calm
              0.5,
              "rgb(234, 179, 8)", // Yellow - Moderate
              0.8,
              "rgb(249, 115, 22)", // Orange - Stressful
              1,
              "rgb(239, 68, 68)", // Red - Chaotic
            ],
            "heatmap-radius": [
              "interpolate",
              ["linear"],
              ["zoom"],
              0,
              2,
              9,
              20,
              15,
              50,
            ],
            "heatmap-opacity": 0.7,
          },
        });

        // Add circle layer for detailed popup interactions when zoomed in
        map.addLayer({
          id: "stress-points",
          type: "circle",
          source: "stress-grid",
          minzoom: 14,
          paint: {
            "circle-radius": 12,
            "circle-color": [
              "interpolate",
              ["linear"],
              ["get", "stress_index"],
              0,
              "rgba(0, 255, 0, 0)",
              20,
              "rgb(34, 197, 94)",
              50,
              "rgb(234, 179, 8)",
              75,
              "rgb(249, 115, 22)",
              100,
              "rgb(239, 68, 68)",
            ],
            "circle-stroke-color": "white",
            "circle-stroke-width": 1,
            "circle-opacity": 0.8,
          },
        });
      } catch (err) {
        console.error("Failed to fetch stress map data", err);
      }
    });

    // Interaction handlers
    map.on("mousemove", "stress-points", (e) => {
      map.getCanvas().style.cursor = "pointer";
      if (e.features && e.features.length > 0) {
        const feature = e.features[0];
        setHoverInfo({
          lngLat: [e.lngLat.lng, e.lngLat.lat],
          props: feature.properties,
        });
      }
    });

    map.on("mouseleave", "stress-points", () => {
      map.getCanvas().style.cursor = "";
      setHoverInfo(null);
    });

    return () => map.remove();
  }, [center, zoom]);

  return (
    <div className="relative w-full h-full rounded-xl overflow-hidden shadow-2xl border border-white/10">
      <div ref={mapContainerRef} className="absolute inset-0" />

      {/* Detail Popup Overlay */}
      {hoverInfo && hoverInfo.props && (
        <div className="absolute top-4 right-4 z-10 bg-black/80 backdrop-blur-md p-4 rounded-xl border border-zinc-700 shadow-xl text-white min-w-[200px] pointer-events-none">
          <h3 className="font-bold text-lg mb-1 flex items-center justify-between">
            Stress Score
            <span
              className={`text-xl font-black ${
                hoverInfo.props.stress_index > 75
                  ? "text-red-500"
                  : hoverInfo.props.stress_index > 50
                    ? "text-orange-500"
                    : hoverInfo.props.stress_index > 25
                      ? "text-yellow-500"
                      : "text-green-500"
              }`}
            >
              {Math.round(hoverInfo.props.stress_index)}
            </span>
          </h3>
          <div className="space-y-1 text-sm text-zinc-300 mt-2">
            <div className="flex justify-between">
              <span>Noise:</span>{" "}
              <span className="font-mono">
                {Math.round(hoverInfo.props.noise_score)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Crowd:</span>{" "}
              <span className="font-mono">
                {Math.round(hoverInfo.props.crowd_score)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Air (AQI):</span>{" "}
              <span className="font-mono">
                {Math.round(hoverInfo.props.aqi_score)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Traffic:</span>{" "}
              <span className="font-mono">
                {Math.round(hoverInfo.props.traffic_score)}
              </span>
            </div>
            <div className="flex justify-between">
              <span>Temp:</span>{" "}
              <span className="font-mono">
                {Math.round(hoverInfo.props.temperature_score)}
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
