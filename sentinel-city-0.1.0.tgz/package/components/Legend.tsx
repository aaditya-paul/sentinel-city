export default function Legend() {
  return (
    <div className="absolute bottom-6 left-6 z-10 bg-black/80 backdrop-blur-md border border-zinc-800 p-4 rounded-xl shadow-2xl text-white text-sm">
      <h4 className="font-semibold mb-3 text-zinc-300">Urban Stress Index</h4>
      <div className="flex items-center gap-3">
        <div className="flex flex-col gap-1 items-center">
          <div className="w-4 h-4 rounded-full bg-green-500 shadow-[0_0_10px_rgba(34,197,94,0.6)]"></div>
          <span className="text-[10px] text-zinc-400">Calm</span>
        </div>
        <div className="h-px w-4 bg-zinc-700"></div>
        <div className="flex flex-col gap-1 items-center">
          <div className="w-4 h-4 rounded-full bg-yellow-500 shadow-[0_0_10px_rgba(234,179,8,0.6)]"></div>
          <span className="text-[10px] text-zinc-400">Mod</span>
        </div>
        <div className="h-px w-4 bg-zinc-700"></div>
        <div className="flex flex-col gap-1 items-center">
          <div className="w-4 h-4 rounded-full bg-orange-500 shadow-[0_0_10px_rgba(249,115,22,0.6)]"></div>
          <span className="text-[10px] text-zinc-400">High</span>
        </div>
        <div className="h-px w-4 bg-zinc-700"></div>
        <div className="flex flex-col gap-1 items-center">
          <div className="w-4 h-4 rounded-full bg-red-500 shadow-[0_0_10px_rgba(239,68,68,0.6)]"></div>
          <span className="text-[10px] text-zinc-400">Chaos</span>
        </div>
      </div>
    </div>
  );
}
