import { NextResponse } from "next/server";
import { createClient } from "@supabase/supabase-js";

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL || "";
// Use the new publishable key standard starting mid-2025
const supabaseKey =
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ||
  "";

// Create a single supabase client for interacting with your database
const supabase = createClient(supabaseUrl, supabaseKey);

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url);
  // Optional bounds: ?minLat=xx&maxLat=xx&minLng=xx&maxLng=xx
  const minLat = searchParams.get("minLat");
  const maxLat = searchParams.get("maxLat");
  const minLng = searchParams.get("minLng");
  const maxLng = searchParams.get("maxLng");

  try {
    let query = supabase.from("locations_grid").select("*");

    if (minLat && maxLat && minLng && maxLng) {
      query = query
        .gte("latitude", parseFloat(minLat))
        .lte("latitude", parseFloat(maxLat))
        .gte("longitude", parseFloat(minLng))
        .lte("longitude", parseFloat(maxLng));
    }

    const { data, error } = await query.limit(5000); // safety limit

    if (error) throw error;

    // Convert flat data to GeoJSON for map compatibility
    const geoJson = {
      type: "FeatureCollection",
      features: data.map((point) => ({
        type: "Feature",
        geometry: {
          type: "Point",
          coordinates: [point.longitude, point.latitude],
        },
        properties: {
          stress_index: point.stress_index,
          noise_score: point.noise_score,
          crowd_score: point.crowd_score,
          aqi_score: point.aqi_score,
          temperature_score: point.temperature_score,
          traffic_score: point.traffic_score,
        },
      })),
    };

    return NextResponse.json(geoJson);
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
