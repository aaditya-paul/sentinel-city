import Map from "@/components/Map";
import Legend from "@/components/Legend";
import { Activity, Search } from "lucide-react";

export default function Home() {
  return (
    <main className="flex h-screen flex-col bg-zinc-950 text-zinc-100 overflow-hidden font-sans">
      {/* Navbar */}
      <header className="flex h-16 items-center justify-between border-b border-zinc-800 bg-zinc-950/80 px-6 backdrop-blur z-20">
        <div className="flex items-center gap-3">
          <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-500/20 text-emerald-500">
            <Activity size={20} />
          </div>
          <h1 className="text-lg font-bold tracking-tight">Urban Stress Map</h1>
        </div>
        <div className="flex items-center gap-4 text-sm font-medium text-zinc-400">
          <div className="flex items-center gap-2 rounded-full border border-zinc-800 bg-zinc-900 px-4 py-1.5 cursor-not-allowed">
            <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
            Kolkata, IN
          </div>
        </div>
      </header>

      {/* Main Content Area */}
      <div className="flex flex-1 relative">
        {/* Sidebar Space for Future Routing Panel */}
        <aside className="w-80 border-r border-zinc-800 bg-zinc-900/50 p-6 flex flex-col gap-6 z-10 backdrop-blur-sm">
          <div>
            <h2 className="text-xl font-bold text-white mb-2">Find Route</h2>
            <p className="text-sm text-zinc-400">
              Discover the calmest path to your destination.
            </p>
          </div>

          <div className="space-y-4">
            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                Start Location
              </label>
              <div className="relative">
                <Search
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500"
                />
                <input
                  disabled
                  type="text"
                  placeholder="e.g. Park Street"
                  className="w-full rounded-lg border border-zinc-800 bg-zinc-950 py-2.5 pl-10 pr-4 text-sm outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 disabled:opacity-50"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-xs font-semibold text-zinc-500 uppercase tracking-wider">
                Destination
              </label>
              <div className="relative">
                <Search
                  size={16}
                  className="absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500"
                />
                <input
                  disabled
                  type="text"
                  placeholder="e.g. Salt Lake Sector V"
                  className="w-full rounded-lg border border-zinc-800 bg-zinc-950 py-2.5 pl-10 pr-4 text-sm outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 disabled:opacity-50"
                />
              </div>
            </div>

            <button
              disabled
              className="mt-2 w-full rounded-lg bg-zinc-800 py-2.5 text-sm font-semibold text-zinc-400 shadow-sm transition-colors hover:bg-zinc-700 disabled:opacity-50"
            >
              Coming Soon
            </button>
          </div>
        </aside>

        {/* Mapbox Container */}
        <div className="flex-1 relative">
          <div className="absolute inset-0 p-4">
            <Map />
            <Legend />
          </div>
        </div>
      </div>
    </main>
  );
}
