import { createClient } from "@supabase/supabase-js";
import dotenv from "dotenv";
import path from "path";

// Load .env.local or .env
dotenv.config({ path: path.resolve(process.cwd(), ".env.local") });
dotenv.config({ path: path.resolve(process.cwd(), ".env") });

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL;

// Use the new secret key standard starting mid-2025 (falls back to service role or publishable)
const supabaseKey =
  process.env.SUPABASE_SECRET_KEY ||
  process.env.SUPABASE_SERVICE_ROLE_KEY ||
  process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY;

if (!supabaseUrl || !supabaseKey) {
  console.error("Missing Supabase credentials in .env.local or .env");
  process.exit(1);
}

const supabase = createClient(supabaseUrl, supabaseKey);

// Kolkata Bounds (very rough box for central/south kolkata to keep MVP small enough)
// Let's do roughly 3km x 3km box to keep row counts reasonable for tests.
const MIN_LAT = 22.52;
const MAX_LAT = 22.58;
const MIN_LNG = 88.33;
const MAX_LNG = 88.37;
const STEP = 0.002; // Roughly 200m

function getRandomNoise() {
  return Math.random() * 100;
}
function getRandomCrowd() {
  return Math.random() * 100;
}
function getRandomAQI() {
  return 40 + Math.random() * 60;
} // Base pollution
function getRandomTemp() {
  return 60 + Math.random() * 40;
} // Usually high temp
function getRandomTraffic() {
  return Math.random() * 100;
}

function calculateStressIndex(noise, crowd, aqi, temp, traffic) {
  // 0.30 noise + 0.25 crowd + 0.20 aqi + 0.15 temp + 0.10 traffic
  let stress =
    0.3 * noise + 0.25 * crowd + 0.2 * aqi + 0.15 * temp + 0.1 * traffic;
  return Math.min(Math.max(stress, 0), 100);
}

async function seedData() {
  console.log("Starting seed for Sentinel City MVP...");

  let rows = [];

  for (let lat = MIN_LAT; lat <= MAX_LAT; lat += STEP) {
    for (let lng = MIN_LNG; lng <= MAX_LNG; lng += STEP) {
      let noise = getRandomNoise();
      let crowd = getRandomCrowd();
      let aqi = getRandomAQI();
      let temp = getRandomTemp();
      let traffic = getRandomTraffic();

      let stress_index = calculateStressIndex(noise, crowd, aqi, temp, traffic);

      rows.push({
        latitude: lat,
        longitude: lng,
        stress_index,
        noise_score: noise,
        crowd_score: crowd,
        aqi_score: aqi,
        temperature_score: temp,
        traffic_score: traffic,
      });
    }
  }

  console.log(`Prepared ${rows.length} rows to insert.`);

  // Clear existing just for dev clean slate
  const { error: delError } = await supabase
    .from("locations_grid")
    .delete()
    .neq("id", 0);
  if (delError) {
    console.error("Error clearing existing grid data:", delError);
  } else {
    console.log("Cleared existing locations.");
  }

  // Insert in batches of 1000
  for (let i = 0; i < rows.length; i += 1000) {
    const chunk = rows.slice(i, i + 1000);
    const { error } = await supabase.from("locations_grid").insert(chunk);
    if (error) {
      console.error("Error inserting chunk:", error);
    } else {
      console.log(`Inserted chunk ${i / 1000 + 1}`);
    }
  }

  console.log("Seed complete!");
}

seedData();
